/**
 * Class used to run TuitionManager class for Program 2.
 * @author Ezra Haleva and Robert Bonagura
 */
public class Prog2
{
   /**
    * Runs TuitionManager class.
    * @param args
    */
   public static void main(String[] args){
      TuitionManager tuitionManager = new TuitionManager();
      tuitionManager.run();
   }
}



